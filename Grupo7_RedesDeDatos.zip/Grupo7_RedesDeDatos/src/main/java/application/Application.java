package application;

import ec.edu.espol.capas.AplicationLayer;
import ec.edu.espol.capas.TransporLayer;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import pool.Sender;

public class Application implements Runnable{
    private AplicationLayer applicationLayer;
    private TransporLayer transportLayer;
    private final int dataSize = 128;
    public static String path;
    private int datosEnviados;
    private int datosRecibidos;

    public PriorityQueue<String> mensajesAlFinalDeTodo = new PriorityQueue<>((o1, o2) -> {
        int id1 = -1;
        try{
            id1 = Integer.parseInt(o1.split("\\|")[0]);
        } catch (NumberFormatException ex){
        }

        int id2 = -1;
        try{
            id2 = Integer.parseInt(o2.split("\\|")[0]);
        } catch (NumberFormatException ex){
        }
        return id1 - id2;
    });
    private Thread t = null;
    public String dataF = "";
    private volatile boolean close = false;
    private volatile boolean sendData = false;
    private volatile boolean sinPerdida = true;
    
    public Application(boolean connectionOriented, boolean sinPerdida) {
        this.applicationLayer = new AplicationLayer(connectionOriented);
        this.transportLayer = new TransporLayer(connectionOriented);
        this.transportLayer.setSourcePort(8080);
        this.transportLayer.setDestinationPort(10);
        this.applicationLayer.conectTransportLayer(transportLayer);
        this.transportLayer.connectToAplicationLayer(applicationLayer);
        this.datosEnviados = 0;
        this.datosRecibidos = 0;
        this.sinPerdida = sinPerdida;
    }
    
    public Application(boolean connectionOriented) {
        this(connectionOriented, false);
    }
    
    public Thread getT() {
        return t;
    }
    
    public void close(){
        close = true;
        this.applicationLayer.close();
    }
    
    public boolean isClosed(){
        return this.close;
    }

    public int getDatosEnviados() {
        return datosEnviados;
    }

    public int getDatosRecibidos() {
        return datosRecibidos;
    }

    public AplicationLayer getApplicationLayer() {
        return applicationLayer;
    }

    public TransporLayer getTransportLayer() {
        return transportLayer;
    }

    public boolean sendFile(String path) throws IOException{
        sendData = true;
        SendFile sf = new SendFile(path);
        new Thread(sf).start();
        return true;
    }
    
    public Thread receiveDataFile(TextArea textArea, Label datosRecibidos) {
        ReceiveFile rf = new ReceiveFile(textArea, datosRecibidos);
        Thread t = new Thread(rf);
        t.start();
        return t;
    }
    
    @Override
    public void run() {
        
        Sender senderAppToTrans = new Sender(applicationLayer,transportLayer, sinPerdida);
        Sender senderTransToApp = new Sender(transportLayer, applicationLayer, sinPerdida);

        Sender senderTransToNetw = new Sender(transportLayer, transportLayer.getNetworkLayer(), sinPerdida);
        Sender senderNetToTrans = new Sender(transportLayer.getNetworkLayer(),transportLayer, sinPerdida);

        Sender senderNetToDat = new Sender(transportLayer.getNetworkLayer(),transportLayer.getNetworkLayer().getDataLinkLayer(), sinPerdida);
        Sender senderDatToNet = new Sender(transportLayer.getNetworkLayer().getDataLinkLayer(),transportLayer.getNetworkLayer(), sinPerdida);

        Sender senderDatToPhy = new Sender(transportLayer.getNetworkLayer().getDataLinkLayer(),transportLayer.getNetworkLayer().getDataLinkLayer().getPhysicalLayer(), sinPerdida);
        Sender senderPhyToDat = new Sender(transportLayer.getNetworkLayer().getDataLinkLayer().getPhysicalLayer(),transportLayer.getNetworkLayer().getDataLinkLayer(), sinPerdida);

        new Thread(senderAppToTrans).start();
        new Thread(senderTransToApp).start();
        new Thread(senderTransToNetw).start();
        new Thread(senderNetToTrans).start();
        new Thread(senderNetToDat).start();
        new Thread(senderDatToNet).start();
        new Thread(senderDatToPhy).start();
        new Thread(senderPhyToDat).start();
        new Thread(()->{
            while(!isClosed()){
                
            }
            senderAppToTrans.finish();
            senderTransToApp.finish();
            senderTransToNetw.finish();
            senderNetToTrans.finish();
            senderNetToDat.finish();
            senderDatToNet.finish();
            senderDatToPhy.finish();
            senderPhyToDat.finish();
        }).start();
    }
    
    
    class ReceiveFile implements Runnable {
        private TextArea textArea;
        private Label labelDatosRecibidos;
        public ReceiveFile(TextArea textArea, Label datosRecibidos) {
            this.textArea = textArea;
            this.labelDatosRecibidos = datosRecibidos;
        }

        @Override
        public void run() {
            boolean fin = false;
            int indiceFinal = -1;
            boolean salioF = false;
            int llegados = 0;
            while (!fin) {
                try {
                    char[] seg = applicationLayer.getPoolInInferior().take();
                    llegados++;
                    if(seg != null){
                        String mensajeFull = new String(seg);
                        System.out.println("\n***" + mensajeFull + "***\n" + mensajesAlFinalDeTodo.size());
                        if (seg.length == 1 && seg[0] == 'f') {
                            salioF = true;
                        }else if(!mensajeFull.contains("|")){
                            try{
                                indiceFinal = Integer.parseInt(mensajeFull);
                            }catch(Exception e){
                                System.out.println(e);
                            }
                        } else {
                            mensajesAlFinalDeTodo.offer(mensajeFull);
                        }
                        System.out.println("\n***" + indiceFinal + "=" + mensajesAlFinalDeTodo.size() + "***\n" );
                        if(salioF && indiceFinal == mensajesAlFinalDeTodo.size()){
                            fin = true;
                        }
                    }else{
                        boolean tomo = false;
                        int tiempo = 1;
                        int tiempoFinal = 7;
                        
                        while(!tomo && tiempo < tiempoFinal){
                            if(sendData){
                                tiempoFinal = 12;
                                sendData = false;
                            }
                            System.out.println("Esperando " + tiempo + " segundos");
                            seg = applicationLayer.getPoolInInferior().take(tiempo++);
                            if(seg == null){
                                if(llegados == indiceFinal){
                                    fin = true;
                                }
                            }else{
                                tomo = true;
                                String mensajeFull = new String(seg);
                                System.out.println("\n***" + mensajeFull + "***\n" + mensajesAlFinalDeTodo.size());
                                if (seg.length == 1 && seg[0] == 'f') {
                                    salioF = true;
                                }else if(!mensajeFull.contains("|")){
                                    indiceFinal = Integer.parseInt(mensajeFull);
                                } else {
                                    mensajesAlFinalDeTodo.offer(mensajeFull);
                                }
                                System.out.println("\n***" + indiceFinal + "=" + mensajesAlFinalDeTodo.size() + "***\n" );
                                if(salioF && indiceFinal == mensajesAlFinalDeTodo.size()){
                                    fin = true;
                                }
                            }
                        }
                        if(!tomo){
                            fin = true;
                        }
                    }
                    
                    if(close){
                        fin = true;
                    }
                } catch (InterruptedException ex) {
                    fin = true;
                }
            }
            if(!close){
                while (!mensajesAlFinalDeTodo.isEmpty()) {
                    String mensaje = mensajesAlFinalDeTodo.poll();
                    String contenido = mensaje.split("\\|")[1];
                    System.out.println(contenido);
                    datosRecibidos += contenido.length();
                    Platform.runLater(() -> {
                        textArea.appendText(contenido);
                        labelDatosRecibidos.setText("Datos recividos: " + datosRecibidos + "\nPaquetes Recibidos: " + (int)(datosRecibidos/dataSize));
                    });
                    
                }
            }
            
            System.out.println("Paró de recibir datos.");
        }
    }
    
    
    class SendFile implements Runnable{
        private String path;
        private SendFile(String path){
            this.path = path;
        }
        
        @Override
        public void run() {
            try {
                sendFile();
            } catch (IOException ex) {
                Logger.getLogger(Application.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        private FileReader openFile(String path){
        try{
            return new FileReader(path);
        } catch (IOException e) {
            return null;
        }
    }
    
    public boolean sendFile() throws IOException{
        ArrayList<char[]> segmentos = new ArrayList<>();
        boolean fin = false;
        FileReader fr = openFile(path);
        int i = 0;
        if(fr != null){
            datosEnviados = 0;
            while(!fin){
                try {
                    char[] data = this.dividirData(fr, i);
                    if(data == null){
                        fin = true;
                        fr.close();
                    }else{
                        System.out.println(i++);
                        segmentos.add(data);
                        
                    }
                } catch (IOException ex) {
                    Logger.getLogger(AplicationLayer.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }else{
            return false;
        }
        System.out.println("segmentosss");
        for(char[] s: segmentos){
            try {
                System.out.println(s);
                if(!applicationLayer.isClosed()){
                    applicationLayer.getPoolInSuperior().add(s);
                }else{
                    return false;
                }
            } catch (InterruptedException ex) {
                Logger.getLogger(Application.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if(!applicationLayer.isClosed()){
            String fString = "f";
            try {
                applicationLayer.getPoolInSuperior().add(fString.toCharArray());
                fString = "" + i;
                applicationLayer.getPoolInSuperior().add(fString.toCharArray());
            } catch (InterruptedException ex) {
                Logger.getLogger(Application.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        return true;
    }
    
    private char[] dividirData(FileReader fr, int indice) throws IOException{
        char[] buffer = new char[dataSize];
        String mensaje = indice + "|";
        int charLeidos = 0;
        int x = 1;
        while(charLeidos<dataSize && x!=-1){
            x = fr.read();
            if(x != -1){
                buffer[charLeidos] = (char)x; 
                charLeidos++;
            }
        }
        if(charLeidos>0){
            String payLoad = new String(buffer);
            String m = mensaje + payLoad + "|"+String.valueOf(charLeidos);
            datosEnviados += payLoad.length();
            return m.toCharArray();
        }
        return null;
    }
        
    }
}
