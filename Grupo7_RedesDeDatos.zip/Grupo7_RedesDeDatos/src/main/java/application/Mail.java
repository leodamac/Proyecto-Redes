/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package application;

/**
 *
 * @author Leo
 */
public class Mail extends Application{
    
    public Mail(boolean sinPerdida, double pPerdida) {
        super(true, sinPerdida, pPerdida, pPerdida);
    }
    
}
