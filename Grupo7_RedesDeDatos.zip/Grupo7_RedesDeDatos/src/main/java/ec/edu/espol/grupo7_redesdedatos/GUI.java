package ec.edu.espol.grupo7_redesdedatos;

import com.mycompany.decision.Main;

public class GUI{

    public static void main(final String[] args) {
        Main.main(args);
    }

}