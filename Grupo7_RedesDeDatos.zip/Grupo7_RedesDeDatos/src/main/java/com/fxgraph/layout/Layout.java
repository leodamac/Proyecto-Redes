package com.fxgraph.layout;

import com.fxgraph.graph.Graph;

public interface Layout {

	public void execute(Graph graph);

}